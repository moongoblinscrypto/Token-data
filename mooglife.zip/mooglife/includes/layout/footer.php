<?php
// mooglife/includes/layout/footer.php
?>
</div> <!-- .main -->
</div> <!-- .layout -->
</body>
</html>
