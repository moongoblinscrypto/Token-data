<?php
// includes/config.php
// Database configuration for Mooglife / GoblinsHQ.

// Adjust these to match what you entered in install.php
define('DB_HOST', 'localhost');      // or your MySQL host
define('DB_USER', 'root');           // your MySQL username
define('DB_PASS', '');               // your MySQL password
define('DB_NAME', 'goblinshq');      // your database name (from installer)
